package com.android.weddingvibes.model;



public class Friend extends User{
    public String id;
    public String idRoom;
}
