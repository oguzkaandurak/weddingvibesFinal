<?php
try {
    $db = new PDO("mysql:host=localhost;dbname=u9366758_hubbigo;charset=utf8", "u9366758_admin", "dMl0X8EuE49v");
} catch (PDOException $e) {
    print $e->getMessage();
}